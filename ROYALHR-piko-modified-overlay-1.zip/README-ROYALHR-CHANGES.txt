ROYALHR Piko Source Modifications
=================================

How to apply:
1. Extract original ROYALHR-source-batch-settings.zip
2. Extract this overlay ZIP on top of it (overwrite files)
3. Build the patches as usual

Changes made:
1. ScreenBuilder.java
   - Removed "Export Piko settings" and "Reset Piko settings" from Backup section
   - Kept Import settings + Import/Export login token

2. ImportExportLoginTokenPatch.java
   - createAllAccountSettingsJsonText() now exports FULL login tokens
     for ALL accounts in one JSON (format: royalhr-all-accounts-login-tokens-v1)

3. ExportLoginTokenFragment.java
   - Default filename for all-accounts export: royalhr_all_accounts_login_tokens.json

4. fragment_export_token.xml
   - Button text: "Export ALL accounts (login tokens JSON)"

5. strings.xml (twitter)
   - "Import Piko settings" → "Import ROYALHR settings"
   - Export/Reset strings also renamed to ROYALHR (though UI entries removed)

